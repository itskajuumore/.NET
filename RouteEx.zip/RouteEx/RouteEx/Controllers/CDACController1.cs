﻿using Microsoft.AspNetCore.Mvc;

namespace RouteEx.Controllers
{
    public class CDACController1 : Controller
    {
        [Route("")]
        [Route("CDAC")]
        [Route("CDAC/Index")]
        public IActionResult Index()
        {
            return View();
        }

        [Route("CDAC/Privacy")]
        public IActionResult Privacy()
        {
            return View();
        }

        public IActionResult Kajal()
        {
            return View();
        }

        [Route("CDAC/PgDac")]
        public IActionResult PgDac()
        {
            return View();
        }

    }
}
