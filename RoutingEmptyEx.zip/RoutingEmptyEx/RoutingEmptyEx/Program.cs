var builder = WebApplication.CreateBuilder(args);
builder.Services.AddControllersWithViews();
var app = builder.Build();

//app.Map("/", () => "Hello World!");
//app.MapGet("/Home", () => new[] { "Hello kajal" });
app.MapControllers();
//app.MapPost("/Home", () => new[] { "Hello kaju" });


app.Run();
