﻿using Microsoft.AspNetCore.Mvc;

namespace RoutingEmptyEx.Controllers
{
    public class HomeController : Controller
    {
        [Route("/Index")]
        public IActionResult Index()
        {
            return View();
        }
    }
}

   /*     public JsonResult JsonResult()
        {
            var name = "kajal More";
            return Json(new {name});
        }
    }
}*/
      
       /* public JsonResult ContentResult()
        {
            return Content("Hello .Net core");
        }
    }
}
*/